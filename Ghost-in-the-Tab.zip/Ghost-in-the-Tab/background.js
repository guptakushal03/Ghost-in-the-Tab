chrome.runtime.onInstalled.addListener(() => {
    console.log("Ghost in the Tab installed!");
});
  